import secrets
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from passlib.hash import bcrypt

from .config import settings
from .database import Base, engine, SessionLocal
from .models import User
from .auth import router as auth_router
from .routers.dashboard import router as dashboard_router
from .routers.links import router as links_router


def init_db():
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        creds_file = Path("admin_credentials.txt")

        def gen_password(length: int = 16) -> str:
            alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
            return "".join(secrets.choice(alphabet) for _ in range(length))

        # Ensure there is always an admin account.
        admin = db.query(User).filter(User.username == "admin").first()

        if admin is None:
            password = gen_password()
            admin = User(username="admin", password_hash=bcrypt.hash(password))
            db.add(admin)
            db.commit()
            creds_file.write_text(f"username=admin\npassword={password}\n")
            print("\n[RootGeek] Initial admin created:")
            print("  Username: admin")
            print(f"  Password: {password}\n")
            return

        # If an admin exists but the credentials file is missing (common when the first-run output was missed),
        # reset the password once and store it, so the project remains "download -> ./start.sh -> login".
        if not creds_file.exists():
            password = gen_password()
            admin.password_hash = bcrypt.hash(password)
            db.add(admin)
            db.commit()
            creds_file.write_text(f"username=admin\npassword={password}\n")
            print("\n[RootGeek] Admin exists, but credentials file was missing -> password was reset:")
            print("  Username: admin")
            print(f"  Password: {password}\n")
            return

        # Always show credentials on startup for convenience (open-source quickstart).
        try:
            creds = creds_file.read_text().strip().splitlines()
            kv = dict(line.split("=", 1) for line in creds if "=" in line)
            if kv.get("username") and kv.get("password"):
                print("\n[RootGeek] Admin login:")
                print(f"  Username: {kv['username']}")
                print(f"  Password: {kv['password']}\n")
        except Exception:
            # Don't block startup if the file is malformed.
            pass
    finally:
        db.close()


def create_app() -> FastAPI:
    app = FastAPI(title=settings.PROJECT_NAME)

    # Static files
    app.mount("/static", StaticFiles(directory="app/static"), name="static")

    # CORS (loose for demo, tighten in prod)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Routers
    app.include_router(auth_router)
    app.include_router(dashboard_router)
    app.include_router(links_router)

    @app.on_event("startup")
    def on_startup():
        init_db()

    return app


app = create_app()
